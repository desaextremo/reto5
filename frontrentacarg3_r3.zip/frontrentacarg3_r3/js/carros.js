//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Car/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let seccionEditar = document.getElementById("editar")
let seccionEliminar = document.getElementById("eliminar")
let botonNuevoCarro =  document.getElementById("botonNuevoCarro")
let botonApliCarroNuevoCarro =  document.getElementById("botonApliCarroNuevoCarro")
let botonAplicarEliminarCarro =  document.getElementById("botonAplicarEliminarCarro")
let botonApliCarroEditarCarro = document.getElementById("botonApliCarroEditarCarro")
let gamaCarro = document.getElementById("gamaCarro")
let gamaEditCarro = document.getElementById("gamaEditCarro")
let gamaDeleteCarro = document.getElementById("gamaDeleteCarro")
let bottonCancelarEditar = document.getElementById("bottonCancelarEditar")
let bottonCancelarEliminar = document.getElementById("bottonCancelarEliminar")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoCarro.addEventListener("click",nuevaCarro)
botonApliCarroNuevoCarro.addEventListener("click",aplicarNuevoCarro)
botonAplicarEliminarCarro.addEventListener("click",aplicarEliminarCarro)
botonApliCarroEditarCarro.addEventListener("click",aplicarEditarCarro)
bottonCancelarNuevo.addEventListener("click",inicial)
bottonCancelarEditar.addEventListener("click",inicial)
bottonCancelarEliminar.addEventListener("click",inicial)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function inicial(){
    seccionNuevo.style.display="none"
    seccionEditar.style.display='none'
    seccionEliminar.style.display='none'
    listar()
    llenaListaGamas()
}

function nuevaCarro(){
    seccionListar.style.display='none'
    seccionEditar.style.display='none'
    seccionEliminar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('nameCarro').value=""
    document.getElementById('descriptionCarro').value=""
    document.getElementById('nameCarro').focus()
}

function aplicarNuevoCarro (){
    url = "http://localhost:8080/api/Car/save"

    //leer datos del formulario
    let nameCarro = document.getElementById('nameCarro').value
    let brandCarro = document.getElementById('brandCarro').value
    let yearCarro = document.getElementById('yearCarro').value
    let gamaCarro = document.getElementById('gamaCarro').value
    let descriptionCarro = document.getElementById('descriptionCarro').value

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        name: nameCarro,
        brand: brandCarro,
        year: yearCarro,
        gama: {
            idGama: gamaCarro
        },
        description: descriptionCarro
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function editarCarro(idCarro){
    seccionListar.style.display='none'
    seccionNuevo.style.display='none'
    seccionEliminar.style.display='none'
    seccionEditar.style.display='block'    

    recuperarInformacionCarro(idCarro,'idEditCarro','nameEditCarro','brandEditCarro','yearEditCarro','gamaEditCarro','descriptionEditCarro','countEditMessagesCarro','countEditReservationCarro')
}

function aplicarEditarCarro(){
    let idEditCarro = document.getElementById("idEditCarro").value
    let nameEditCarro = document.getElementById("nameEditCarro").value
    let brandEditCarro = document.getElementById("brandEditCarro").value
    let yearEditCarro = document.getElementById("yearEditCarro").value
    let descriptionEditCarro = document.getElementById("descriptionEditCarro").value
    url="http://localhost:8080/api/Car/update"
   
    axios.put(url,{
        idCar:idEditCarro,
        name: nameEditCarro,
        brand:brandEditCarro,
        year:yearEditCarro,
        description:descriptionEditCarro
    })
    .then(function (response) {
        console.log(response.data)
        inicial()
    }).catch(function (error){
        console.log(error)
    })    
}

function borrarCarro(idCarro){
    seccionListar.style.display='none'
    seccionNuevo.style.display='none'
    seccionEditar.style.display='none'
    seccionEliminar.style.display='block'    

    recuperarInformacionCarro(idCarro,'idDeleteCarro','nameDeleteCarro','brandDeleteCarro','yearDeleteCarro','gamaDeleteCarro','descriptionDeleteCarro','countMsgDeleteCarro','countRsvDeleteCarro')
}

function aplicarEliminarCarro(){
    let idDeleteCarro = document.getElementById("idDeleteCarro").value

    url="http://localhost:8080/api/Car"
    
    axios.delete(url + "/" + idDeleteCarro)
    .then(function (response) {
        console.log(response.data)
        inicial()
    }).catch(function (error){
        console.log(error)
    })
}

      
function recuperarInformacionCarro(idCarro,idName,nameId,brandId,yearId,gamaId,descriptionId,cantMsg,cantRsv){
    url="http://localhost:8080/api/Car"
    //peticion http de tipo get
    axios.get(url + "/" + idCarro)
    .then(function (response) {
      let items = response.data

      let gama = items.gama
      let idGama = ""
      if (gama !==null) idGama = items.gama.idGama
      console.log(items)
      document.getElementById(idName).value = items.idCar
      document.getElementById(nameId).value = items.name                                                   
      document.getElementById(brandId).value = items.brand
      document.getElementById(yearId).value = items.year
      document.getElementById(gamaId).value = idGama
      document.getElementById(descriptionId).value = items.description
      document.getElementById(cantMsg).value = items.messages.length
      document.getElementById(cantRsv).value = items.reservations.length

      let countMsgId = items.messages.length
      let countRsvId = items.reservations.length
        
      countMsgId = parseInt(countMsgId)
      countRsvId = parseInt(countRsvId)

      if ((countMsgId > 0 ) || (countRsvId > 0 )) botonAplicarEliminarCarro.disabled = true
      else botonAplicarEliminarCarro.disabled = false
    
    }).catch(function (error){
        console.log(error)
    })
}

function listar(){
    url="http://localhost:8080/api/Car/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            let gama = items[i].gama;
            let nombreGama=""
            if (gama !== null) nombreGama = items[i].gama.name
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idCar + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].brand + '</td>' +
                            '<td>' + items[i].year + '</td>' +
                            '<td>' + nombreGama + '</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary" onclick="editarCarro(' +  items[i].idCar + ')">Editar</button>' +
                            '    <button class="btn btn-outline-primary" onclick="borrarCarro(' +  items[i].idCar + ')">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaGamas(){
    url="http://localhost:8080/api/Gama/all"
    let listaGamas=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaGamas +=  '<option value="' + items[i].idGama + '">' + items[i].name +'</option>'
        }
        gamaCarro.innerHTML = listaGamas
        gamaDeleteCarro.innerHTML = listaGamas
        gamaEditCarro.innerHTML = listaGamas
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

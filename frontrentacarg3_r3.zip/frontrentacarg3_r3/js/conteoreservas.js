//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let inicioReserva = document.getElementById("inicioReserva")
let finReserva = document.getElementById("finReserva")
let seccionListar = document.getElementById("listar")
let botonConsultar = document.getElementById("botonConsultar")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonConsultar.addEventListener("click",listar)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function inicial(){
    seccionListar.style.display="none"
}


function listar(){

    let fInicial = inicioReserva.value
    let fFinal = finReserva.value
    let url='http://localhost:8080/api/Reservation/report-dates/'+ fInicial + '/' + fFinal
    
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idReservation + ' </td>' + 
                            '<td>' + items[i].client.name  + '</td>' +
                            '<td>' + items[i].car.name  + ' - ' + items[i].car.brand +'</td>' +
                            '<td>' + items[i].startDate +'</td>' +                            
                            '<td>' + items[i].devolutionDate +'</td>' +
                            '<td>' + items[i].status +'</td>' +
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

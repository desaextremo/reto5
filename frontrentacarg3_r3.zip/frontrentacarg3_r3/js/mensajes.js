//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Message/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let seccionEditar = document.getElementById("editar")
let seccionEliminar = document.getElementById("eliminar")
let botonNuevoMensaje =  document.getElementById("botonNuevoMensaje")
let bottonCancelarNuevo =  document.getElementById("bottonCancelarNuevo")
let botonAplicarEditMsg =  document.getElementById("botonAplicarEditMsg")
let botonAplicarDelMsg =  document.getElementById("botonAplicarDelMsg")
let bottonCancelarEditMsg =  document.getElementById("botonCancelarEditMsg")
let botonCancelarDelMsg =  document.getElementById("botonCancelarDelMsg")
let botonAplicarNuevoMensaje =  document.getElementById("botonAplicarNuevoMensaje")
let clienteMensaje = document.getElementById("clienteMensaje")
let carroMensaje = document.getElementById("carroMensaje")
let clienteEditMsg = document.getElementById("clienteEditMsg")
let carroEditMsg = document.getElementById("carroEditMsg")
let clienteDelMsg = document.getElementById("clienteDelMsg")
let carroDelMsg = document.getElementById("carroDelMsg")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoMensaje.addEventListener("click",nuevaMensaje)
botonAplicarNuevoMensaje.addEventListener("click",aplicarMensaje)
bottonCancelarNuevo.addEventListener("click",inicial)
bottonCancelarEditMsg.addEventListener("click",inicial)
botonCancelarDelMsg.addEventListener("click",inicial)
botonAplicarEditMsg.addEventListener("click",aplicarEditarMensaje)
botonAplicarDelMsg.addEventListener("click",aplicarEliminarMensaje)
//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaMensaje(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    seccionEditar.style.display='none'
    seccionEliminar.style.display='none'
    document.getElementById('descriptionMensaje').value=""
    document.getElementById('clienteMensaje').focus()
}

function inicial(){
    document.getElementById('descriptionMensaje').value=""    
    seccionNuevo.style.display="none"
    seccionEditar.style.display='none'
    seccionEliminar.style.display='none'
    listar()
    llenaListaClientes()
    llenaListaCarros()
}

function aplicarMensaje (){
    url = "http://localhost:8080/api/Message/save"

    //leer datos del formulario
    let descriptionMensaje = document.getElementById('descriptionMensaje').value
    let clienteMensaje = document.getElementById('clienteMensaje').value
    let carroMensaje = document.getElementById('carroMensaje').value
    
    

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        messageText: descriptionMensaje,
        client: {
            idClient: clienteMensaje
        },
        car: {
            idCar: carroMensaje
        }
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function editarMensaje(idMsg){
    seccionListar.style.display='none'
    seccionNuevo.style.display='none'
    seccionEditar.style.display='block'
    seccionEliminar.style.display='none'
    document.getElementById('clienteEditMsg').focus()

    recuperarInformacionMsg(idMsg,'idEditMsg','clienteEditMsg','carroEditMsg','descEditMsg')
}

function aplicarEditarMensaje (){
    let url = "http://localhost:8080/api/Message/update"

    //leer datos del formulario
    let idEditMsg = document.getElementById('idEditMsg').value
    let clienteEditMsg = document.getElementById('clienteEditMsg').value
    let carroEditMsg = document.getElementById('carroEditMsg').value
    let descEditMsg = document.getElementById('descEditMsg').value
    
    

    //generar peticion tipo post con la libreria axios
    axios.put(url,{
        idMessage: idEditMsg,
        messageText:descEditMsg,
        car: {
            idCar: carroEditMsg
        },
        client: {
            idClient: clienteEditMsg
        }  
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function eliminarMensaje(idMsg){
    seccionListar.style.display='none'
    seccionNuevo.style.display='none'
    seccionEditar.style.display='none'
    seccionEliminar.style.display='block'
    recuperarInformacionMsg(idMsg,'idDelMsg','clienteDelMsg','carroDelMsg','descDelMsg')
}

function aplicarEliminarMensaje (){
    let url = "http://localhost:8080/api/Message"

    //leer datos del formulario
    let idDelMsg = document.getElementById('idDelMsg').value
    
    //generar peticion tipo post con la libreria axios
    axios.delete(url + "/" + idDelMsg)
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function listar(){
    url="http://localhost:8080/api/Message/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idMessage + ' </td>' + 
                            '<td>' + items[i].client.name +'</td>' +
                            '<td>' + items[i].car.name + ' - ' + items[i].car.brand + '</td>' +
                            '<td>' + items[i].messageText + '</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary" onclick="editarMensaje(' +  items[i].idMessage + ')">Editar</button>' +
                            '    <button class="btn btn-outline-primary" onclick="eliminarMensaje(' +  items[i].idMessage + ')">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function recuperarInformacionMsg(idMsg,idIdMsg,cliMsgId,carMsgId,descMsgId){
    url="http://localhost:8080/api/Message"
    //peticion http de tipo get
    axios.get(url + "/" + idMsg)
    .then(function (response) {
      let items = response.data
  
      document.getElementById(idIdMsg).value = items.idMessage
      document.getElementById(cliMsgId).value = items.client.idClient                                                   
      document.getElementById(carMsgId).value = items.car.idCar
      document.getElementById(descMsgId).value = items.messageText
    })
  }

function llenaListaClientes(){
    url="http://localhost:8080/api/Client/all"
    let listaClientes=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaClientes +=  '<option value="' + items[i].idClient + '">' + items[i].name +'</option>'
        }
        clienteMensaje.innerHTML = listaClientes
        clienteEditMsg.innerHTML = listaClientes
        clienteDelMsg.innerHTML = listaClientes
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaCarros(){
    url="http://localhost:8080/api/Car/all"
    let listaCarros=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaCarros +=  '<option value="' + items[i].idCar + '">' + items[i].name + ' - ' + items[i].brand +'</option>'
        }
        carroMensaje.innerHTML = listaCarros
        carroEditMsg.innerHTML = listaCarros
        carroDelMsg.innerHTML = listaCarros

        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

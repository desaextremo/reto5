//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Client/all"

//Acceder a un elemento html que se identifica por un id
let seccionNuevo = document.getElementById("nuevo")
let seccionEditar = document.getElementById("editar")
let seccionEliminar = document.getElementById("eliminar")
let seccionListar = document.getElementById("listar")
let tableBody = document.getElementById("tableBody")
let botonAplicarClienteNuevo =  document.getElementById("botonAplicarClienteNuevo")
let botonAplicarClienteEditar =  document.getElementById("botonAplicarClienteEditar")
let botonAplicarEliminarCliente = document.getElementById("botonAplicarEliminarCliente")
let bottonCancelarNuevo =  document.getElementById("bottonCancelarNuevo")
let bottonCancelarEditar = document.getElementById("bottonCancelarEditar")
let bottonCancelarEliminar = document.getElementById("bottonCancelarEliminar")

//registro de eventos
botonNuevoCliente.addEventListener("click",nuevaCliente)
botonAplicarClienteNuevo.addEventListener("click",aplicarNuevoCliente)
botonAplicarClienteEditar.addEventListener("click",aplicarEditarCliente)
botonAplicarEliminarCliente.addEventListener("click",aplicarBorrarCliente)
bottonCancelarNuevo.addEventListener("click",inicial)
bottonCancelarEditar.addEventListener("click",inicial)
bottonCancelarEliminar.addEventListener("click",inicial)

//almacena html de los registros a presentar en el listado de Clientes <tr><td>....</td></td></tr>
let resultados = ""

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function inicial(){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="none"
    listar()
}

function nuevaCliente(){
    seccionNuevo.style.display="block"    
    seccionListar.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="none"
    document.getElementById("nameCliente").focus()
}

function aplicarNuevoCliente(){
    url="http://localhost:8080/api/Client/save"
    //leer informacion del Cliente editado o modificado
    let nameCliente = document.getElementById('nameCliente').value
    let emailCliente = document.getElementById('emailCliente').value
    let passwordCliente = document.getElementById('passwordCliente').value
    let edadCliente = document.getElementById('edadCliente').value
  
    axios.post(url, {
      name: nameCliente,
      email:emailCliente,
      password: passwordCliente,
      age: edadCliente
  })
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()      
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
}

function editarCliente(idClient){
  seccionNuevo.style.display="none"
  seccionEditar.style.display="block"
  seccionEliminar.style.display="none" 
  seccionListar.style.display="none" 

  //invocar a ws que recupera la gama por id
  recuperarInformacionCliente(idClient,'idEditCliente','nameEditCliente','emailEditCliente','passwordEditCliente','edadEditCliente','countEditMsgCliente','countEditRsvCliente')
}

function aplicarEditarCliente(){
  let idEditCliente = document.getElementById("idEditCliente").value
  let nameEditCliente = document.getElementById("nameEditCliente").value
  let emailEditCliente = document.getElementById("emailEditCliente").value
  let passwordEditCliente = document.getElementById("passwordEditCliente").value
  let edadEditCliente = document.getElementById("edadEditCliente").value

  url="http://localhost:8080/api/Client/update"
 
  axios.put(url,{
    idClient:idEditCliente,
    name: nameEditCliente,
    email:emailEditCliente,
    password:passwordEditCliente,
    age:edadEditCliente
  })
  .then(function (response) {
      console.log(response.data)
      inicial()
  }).catch(function (error){
      console.log(error)
  })    
}

function eliminarCliente(idClient){
  seccionNuevo.style.display="none"
  seccionEditar.style.display="none"
  seccionEliminar.style.display="block" 
  seccionListar.style.display="none" 

  //invocar a ws que recupera la gama por id
  recuperarInformacionCliente(idClient,'idDeleteCliente','nameDeleteCliente','emailDeleteCliente','passwordDeleteCliente','edadDeleteCliente','countDelMsgCliente','countDelRsvCliente')
}

function aplicarBorrarCliente(){
  let idDeleteCliente = document.getElementById("idDeleteCliente").value
  

  url="http://localhost:8080/api/Client"
  
  axios.delete(url + "/" + idDeleteCliente)
  .then(function (response) {
      console.log(response.data)
      inicial()
  }).catch(function (error){
      console.log(error)
  })
}

function recuperarInformacionCliente(idClient,idCliente,nameCliente,emailCliente,passwordCliente,edadCliente,countMsg,countRsv){
  url="http://localhost:8080/api/Client"
  //peticion http de tipo get
  axios.get(url + "/" + idClient)
  .then(function (response) {
    let items = response.data

    document.getElementById(idCliente).value = items.idClient
    document.getElementById(nameCliente).value = items.name                                                   
    document.getElementById(emailCliente).value = items.email
    document.getElementById(passwordCliente).value = items.password
    document.getElementById(edadCliente).value = items.age
    document.getElementById(countMsg).value = items.messages.length
    document.getElementById(countRsv).value = items.reservations.length

    let countMsgId = items.messages.length
    let countRsvId = items.reservations.length
        
    countMsgId = parseInt(countMsgId)
    countRsvId = parseInt(countRsvId)

    if ((countMsgId > 0 ) || (countRsvId > 0 )) botonAplicarEliminarCliente.disabled = true
     else botonAplicarEliminarCliente.disabled = false
  })
}

function listar(){
    url="http://localhost:8080/api/Client/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idClient + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].email +'</td>' +
                            '<td>' + items[i].age +'</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary" onclick="editarCliente(' +  items[i].idClient + ')">Editar</button>' +
                            '    <button class="btn btn-outline-primary" onclick="eliminarCliente(' +  items[i].idClient + ')">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

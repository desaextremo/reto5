//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""



//se ejecuta la consulta al inicio
listar()


function listar(){
    let url='http://localhost:8080/api/Reservation/report-status'
    
    axios.get(url)
    .then(function (response){
        let items = response.data
        resultados +=  '<tr>' + 
                            '<td>' + items.completed + ' </td>' +
                            '<td>' + items.cancelled  + '</td>'  +
                        '</tr>'
        tableBody.innerHTML = resultados
        
    })
    .catch(function (error){
        console.log(error)
    })
}

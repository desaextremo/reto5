//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Gama/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let seccionEditar = document.getElementById("editar")
let seccionEliminar = document.getElementById("eliminar")

let botonNuevoGama =  document.getElementById("botonNuevoGama")
let botonApliGamaNuevoGama =  document.getElementById("botonApliGamaNuevoGama")
let bottonCancelarEliminar = document.getElementById("bottonCancelarEliminar")
let bottonCancelarEditar = document.getElementById("bottonCancelarEditar")
let botonAplicarEliminarGama = document.getElementById("botonAplicarEliminarGama")
let botonApliGamaEditarGama = document.getElementById("botonApliGamaEditarGama")


//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoGama.addEventListener("click",nuevaGama)
botonApliGamaNuevoGama.addEventListener("click",aplicarNuevoGama)
bottonCancelarNuevo.addEventListener("click",inicial)
bottonCancelarEliminar.addEventListener("click",inicial)
bottonCancelarEditar.addEventListener("click",inicial)
botonAplicarEliminarGama.addEventListener("click",aplicarEliminarGama)
botonApliGamaEditarGama.addEventListener("click",aplicarEditarGama)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaGama(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('nameGama').value=""
    document.getElementById('descriptionGama').value=""
    document.getElementById('nameGama').focus()
}

function inicial(){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="none"
    listar()
}

function aplicarNuevoGama (){
    url = "http://localhost:8080/api/Gama/save"

    //leer datos del formulario
    let nameGama = document.getElementById('nameGama').value
    let descriptionGama = document.getElementById('descriptionGama').value

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        name: nameGama,
        description: descriptionGama
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function editarGama(idGama){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="block"
    seccionEliminar.style.display="none" 
    seccionListar.style.display="none"
    document.getElementById("nameEditGama").focus()

    //invocar a ws que recupera la gama por id
    recuperarInformacionGama(idGama,'idEditGama','nameEditGama','descriptionEditGama','countCarsEditGama')
}

function aplicarEditarGama(){
    let idEditGama = document.getElementById("idEditGama").value
    let nameEditGama = document.getElementById("nameEditGama").value
    let descriptionEditGama = document.getElementById("descriptionEditGama").value

    url="http://localhost:8080/api/Gama/update"
   
    axios.put(url,{
        idGama:idEditGama,
        name: nameEditGama,
        description:descriptionEditGama
    })
    .then(function (response) {
        console.log(response.data)
        inicial()
    }).catch(function (error){
        console.log(error)
    })    
}

function borrarGama(idGama){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="block" 
    seccionListar.style.display="none" 
    
    //invocar a ws que recupera la gama por id
    recuperarInformacionGama(idGama,'idDeleteGama','nameDeleteGama','descriptionDeleteGama','countCarsDeleteGama')
}

function aplicarEliminarGama(){
    //leer informacion del carro editado o modificado
    let idDeleteGama = document.getElementById("idDeleteGama").value
    url="http://localhost:8080/api/Gama"

    axios.delete(url + "/" + idDeleteGama)
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
  }

function recuperarInformacionGama(idGama,idName,nameId,descriptionId,countCarsId){
    url="http://localhost:8080/api/Gama"
    //peticion http de tipo get
    axios.get(url + "/" + idGama)
    .then(function (response) {
      let items = response.data
  
      console.log(response.data)
      console.log(items.idGama)
      console.log(items.name)
      console.log(items.description)
      document.getElementById(idName).value = items.idGama
      document.getElementById(nameId).value = items.name                                                   
      document.getElementById(descriptionId).value = items.description
      document.getElementById(countCarsId).value = items.cars.length
      let countCars = document.getElementById(countCarsId).value ;
      //Convierte  entero
      countCars  = parseInt(countCars)
      if  (countCars > 0) botonAplicarEliminarGama.disabled = true
			else botonAplicarEliminarGama.disabled = false
            
    })
}


function listar(){
    url="http://localhost:8080/api/Gama/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idGama + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].description.substring(0, 20) +'...</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary" onclick="editarGama(' +  items[i].idGama + ')">Editar</button>' +
                            '    <button class="btn btn-outline-primary" onclick="borrarGama(' +  items[i].idGama + ')">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

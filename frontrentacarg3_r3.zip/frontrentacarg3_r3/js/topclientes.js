//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""



//se ejecuta la consulta al inicio
listar()


function listar(){
    let url='http://localhost:8080/api/Reservation/report-clients'
    
    axios.get(url)
    .then(function (response){
        let items = response.data
        
        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].total + ' </td>' + 
                            '<td>' + items[i].client.name  + '</td>' +
                            '<td>' + items[i].client.email +'</td>' +
                            '<td>' + items[i].client.age +'</td>' +
                        '</tr>'
        }
        
        tableBody.innerHTML = resultados
        
    })
    .catch(function (error){
        console.log(error)
    })
}

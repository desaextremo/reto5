//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://localhost:8080/api/Reservation/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let botonNuevoReserva =  document.getElementById("botonNuevoReserva")
let botonAplicarNuevoReserva =  document.getElementById("botonAplicarNuevoReserva")
let clienteMensaje = document.getElementById("clienteMensaje")
let carroMensaje = document.getElementById("carroMensaje")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoReserva.addEventListener("click",nuevaMensaje)
botonAplicarNuevoReserva.addEventListener("click",aplicarReserva)
bottonCancelarNuevo.addEventListener("click",inicial)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaMensaje(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('clienteReserva').focus()
}

function inicial(){
    seccionNuevo.style.display="none"
    listar()
    llenaListaClientes()
    llenaListaCarros()
}

function aplicarReserva (){
    url = "http://localhost:8080/api/Reservation/save"

    //leer datos del formulario
    let inicioReserva = document.getElementById('inicioReserva').value
    let finReserva = document.getElementById('finReserva').value
    let clienteReserva = document.getElementById('clienteReserva').value
    let carroReserva = document.getElementById('carroReserva').value
    
    

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        startDate: inicioReserva,
        devolutionDate: finReserva,
        client: {
            idClient: clienteReserva
        },
        car: {
            idCar: carroReserva
        }
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function listar(){
    url="http://localhost:8080/api/Reservation/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        console.log(response.data)

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idReservation + ' </td>' + 
                            '<td>' + items[i].client.name +'</td>' +
                            '<td>' + items[i].car.name +'</td>' +
                            '<td>' + items[i].startDate + '</td>' +
                            '<td>' + items[i].devolutionDate + '</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary">Editar</button>' +
                            '    <button class="btn btn-outline-primary">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaClientes(){
    url="http://localhost:8080/api/Client/all"
    let listaClientes=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaClientes +=  '<option value="' + items[i].idClient + '">' + items[i].name +'</option>'
        }
        clienteReserva.innerHTML = listaClientes
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

function llenaListaCarros(){
    url="http://localhost:8080/api/Car/all"
    let listaCarros=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            listaCarros +=  '<option value="' + items[i].idCar + '">' + items[i].name + ' - ' + items[i].brand +'</option>'
        }
        carroReserva.innerHTML = listaCarros
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

package com.atenea.retacarg5_r3;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class Retacarg5R3ApplicationTests {

}

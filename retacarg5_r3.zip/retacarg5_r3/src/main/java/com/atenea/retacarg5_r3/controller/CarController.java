package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Car")
@CrossOrigin(origins = "*")
public class CarController {
    @Autowired
    private CarService business;

    //listar carros
    @GetMapping("/all")
    public List<Car> getCars(){
        return business.getCars();
    }

    //Lista un carro a partir de su id
    @GetMapping("/{id}")
    public Optional<Car> getCar(@PathVariable("id") Long carId){
        return business.getCar(carId);
    }

    //ingresar Carros
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addCar(@RequestBody Car car){
        business.addCar(car);
    }

    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Car saveCar(@RequestBody Car objeto){
        return business.saveCar(objeto);
    }

    //borrar un carro
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCar(@PathVariable("id") Long idCar) {
        business.deleteCar(idCar);
    }
}

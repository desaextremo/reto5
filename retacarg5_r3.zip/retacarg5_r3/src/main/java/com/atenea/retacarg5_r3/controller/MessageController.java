package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.entity.Message;
import com.atenea.retacarg5_r3.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Message/")
@CrossOrigin(origins = "*")
public class MessageController {
    @Autowired
    private MessageService businness;

    //Listar mensajes
    @GetMapping("/all")
    public List<Message> getMessages(){
        return businness.getMessages();
    }

    //Lista un mensaje a partir de su id
    @GetMapping("/{id}")
    public Optional<Message> getMessage(@PathVariable("id") Long messageId){
        return businness.getMessage(messageId);
    }

    //agregar mensaje
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addMessage(@RequestBody Message message){
        businness.addMessage(message);
    }

    //actualizar un mensaje
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Message saveMessage(@RequestBody Message objeto){
        return businness.saveMessage(objeto);
    }

    //borrar un mensaje
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMessage(@PathVariable("id") Long clientId) {
        businness.deleteMessage(clientId);
    }
}

package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.entity.Message;
import com.atenea.retacarg5_r3.entity.Reservation;
import com.atenea.retacarg5_r3.pojo.CountClient;
import com.atenea.retacarg5_r3.pojo.StatusAmount;
import com.atenea.retacarg5_r3.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository repository;

    //Listar mensajes
    public List<Reservation> getReservations(){
        return repository.findAll();
    }

    //Lista una reserva a partir de su id
    public Optional<Reservation> getReservation(Long reservationId){ return repository.findById(reservationId); }

    //agregar reserva
    public void addReservation(Reservation reservation){
        repository.save(reservation);
    }

    //Actualizar un reserva
    public Reservation saveReservation(Reservation objeto){
        if (objeto.getIdReservation()!= null){
            Optional<Reservation> optional = repository.findById(objeto.getIdReservation());

            if(optional.isPresent()){
                Reservation reservationDb = optional.get();

                if (objeto.getStartDate()!=null) reservationDb.setStartDate(objeto.getStartDate());
                if (objeto.getDevolutionDate()!=null) reservationDb.setDevolutionDate(objeto.getDevolutionDate());
                if (objeto.getCar()!=null) reservationDb.setCar(objeto.getCar());
                if (objeto.getClient()!=null) reservationDb.setClient(objeto.getClient());

                return repository.save(reservationDb);
            }
        }
        return objeto;
    }

    //borrar un reserva
    public void deleteReservation(Long reservationId){
        repository.deleteById(reservationId);
    }

    //Conteo de Reservas: Saber cuántas reservas se han hecho en un intervalo de tiempo
    public List<Reservation> getReservationPeriod(String dateA, String dateB){
        SimpleDateFormat parser=new SimpleDateFormat("yyyy-MM-dd");
        Date a= new Date();
        Date b=new Date();
        try {
            a = parser.parse(dateA);
            b = parser.parse(dateB);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if(a.before(b)){
            return repository.findAllByStartDateAfterAndStartDateBefore(a,b);
        }else{
            return new ArrayList<>();
        }
    }

    //Conteo de Reservas completadas vs canceladas: reporte de reservas con la cantidad de completas vs la cantidad de reservas canceladas
    public List<Reservation> getReservationsByStatus(String status){
        return repository.findAllByStatus(status);
    }

    public StatusAmount getReservationsByStatusReport(){
        List<Reservation>completed=getReservationsByStatus("completed");
        List<Reservation>cancelled=getReservationsByStatus("cancelled");
        return new StatusAmount(completed.size(),cancelled.size());
    }

    //Top mejores clientes:Saber los que más han rentado.
    public  List<CountClient> getTopClients(){
        List<CountClient>res=new ArrayList<>();
        List<Object[]>report=repository.countTotalReservationsByClient();
        for (Object[] objects : report) {
            res.add(new CountClient((Long) objects[1], (Client) objects[0]));
        }
        return res;
    }
}

package com.atenea.retacarg5_r3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.atenea.retacarg5_r3.entity.Car;

public interface CarRepository extends JpaRepository<Car,Long> {
}

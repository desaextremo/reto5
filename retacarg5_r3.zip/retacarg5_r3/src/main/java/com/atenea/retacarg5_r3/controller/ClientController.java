package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/Client/")
@CrossOrigin(origins = "*")
public class ClientController {
    @Autowired
    private ClientService business;

    //listar clientes
    @GetMapping("/all")
    public List<Client> getCLients(){
        return business.getCLients();
    }

    //Lista un cliente a partir de su id
    @GetMapping("/{id}")
    public Optional<Client> getClient(@PathVariable("id") Long clientId){
        return business.getClient(clientId);
    }

    //agregar clientes
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addClient(@RequestBody Client client){
        business.addClient(client);
    }

    //actaulizar un cliente
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Client saveClient(@RequestBody Client objeto){
        return business.saveClient(objeto);
    }

    //borrar un clientes
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCar(@PathVariable("id") Long clientId) {
        business.deleteCar(clientId);
    }
}

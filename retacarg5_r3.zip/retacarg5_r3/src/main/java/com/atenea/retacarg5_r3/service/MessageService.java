package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.entity.Message;
import com.atenea.retacarg5_r3.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MessageService {
    @Autowired
    private MessageRepository repository;

    //Listar mensajes
    public List<Message> getMessages(){
        return repository.findAll();
    }

    //Lista un mensaje a partir de su id
    public Optional<Message> getMessage(Long messageId){ return repository.findById(messageId); }

    //agregar mensaje
    public void addMessage(Message message){
        repository.save(message);
    }

    //Actualizar un mensaje
    public Message saveMessage(Message objeto){
        if (objeto.getIdMessage()!= null){
            Optional<Message> optional = repository.findById(objeto.getIdMessage());

            if(optional.isPresent()){
                Message messageDb = optional.get();

                if (!objeto.getMessageText().equals("")) messageDb.setMessageText(objeto.getMessageText());
                if (objeto.getClient()!=null) messageDb.setClient(objeto.getClient());
                if (objeto.getCar()!=null) messageDb.setCar(objeto.getCar());

                return repository.save(messageDb);
            }
        }
        return objeto;
    }

    //borrar un mensaje
    public void deleteMessage(Long messageId){
        repository.deleteById(messageId);
    }
}

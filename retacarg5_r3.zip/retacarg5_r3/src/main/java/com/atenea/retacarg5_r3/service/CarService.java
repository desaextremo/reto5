package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.entity.Gama;
import com.atenea.retacarg5_r3.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarService {
    @Autowired
    CarRepository repository;

    //listar carros
    public List<Car> getCars(){
        return repository.findAll();
    }

    //Lista un carro a partir de su id
    public Optional<Car> getCar(Long carId){
       return repository.findById(carId);
    }

    //registrar un carro
    public void addCar(Car car){
        repository.save(car);
    }

    //Actualizar un carro
    public Car saveCar(Car objeto){
        if (objeto.getIdCar()!= null){
            Optional<Car> optional = repository.findById(objeto.getIdCar());

            if(optional.isPresent()){
                Car carroDb = optional.get();

                if (!objeto.getName().equals("")) carroDb.setName(objeto.getName());
                if (!objeto.getDescription().equals("")) carroDb.setDescription(objeto.getDescription());
                if (!objeto.getBrand().equals("")) carroDb.setBrand(objeto.getBrand());
                //if (objeto.getGama()!=null) carroDb.setGama(objeto.getGama());
                if (objeto.getYear()!= 0) carroDb.setYear(objeto.getYear());

                return repository.save(carroDb);
            }
        }
        return objeto;
    }

    //borrar un carro
    public void deleteCar(Long idCar){
        repository.deleteById(idCar);
    }

}

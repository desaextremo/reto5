package com.atenea.retacarg5_r3.service;


import com.atenea.retacarg5_r3.entity.Car;
import com.atenea.retacarg5_r3.entity.Client;
import com.atenea.retacarg5_r3.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientService {
    @Autowired
    private ClientRepository repository;

    //listar clientes
    public List<Client> getCLients(){
        return repository.findAll();
    }

    //Lista un cliente a partir de su id
    public Optional<Client> getClient(Long clientId){
        return repository.findById(clientId);
    }

    //agregar clientes
    public void addClient(Client client){
        repository.save(client);
    }

    //Actualizar un cliente
    public Client saveClient(Client objeto){
        if (objeto.getIdClient()!= null){
            Optional<Client> optional = repository.findById(objeto.getIdClient());

            if(optional.isPresent()){
                Client clientDb = optional.get();

                if (!objeto.getName().equals("")) clientDb.setName(objeto.getName());
                if (!objeto.getEmail().equals("")) clientDb.setEmail(objeto.getEmail());
                if (!objeto.getPassword().equals("")) clientDb.setPassword(objeto.getPassword());
                //if (objeto.getGama()!=null) carroDb.setGama(objeto.getGama());
                if (objeto.getAge()!= 0) clientDb.setAge(objeto.getAge());

                return repository.save(clientDb);
            }
        }
        return objeto;
    }

    //borrar un cliente
    public void deleteCar(Long idClient){
        repository.deleteById(idClient);
    }
}

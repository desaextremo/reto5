package com.atenea.retacarg5_r3.controller;

import com.atenea.retacarg5_r3.entity.Message;
import com.atenea.retacarg5_r3.entity.Reservation;
import com.atenea.retacarg5_r3.pojo.CountClient;
import com.atenea.retacarg5_r3.pojo.StatusAmount;
import com.atenea.retacarg5_r3.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/Reservation/")
@CrossOrigin(origins = "*")
public class ReservationController {
    @Autowired
    private ReservationService businness;

    //Listar mensajes
    @GetMapping("/all")
    public List<Reservation> getReservations(){
        return businness.getReservations();
    }

    //Lista un mensaje a partir de su id
    @GetMapping("/{id}")
    public Optional<Reservation> getReservation(@PathVariable("id") Long reservationId){
        return businness.getReservation(reservationId);
    }

    //agregar mensaje
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public void addReservation(@RequestBody Reservation reservation){
        businness.addReservation(reservation);
    }

    //actualziar una reserva
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Reservation saveReservation(@RequestBody Reservation objeto){
        return businness.saveReservation(objeto);
    }

    //borrar una reserva
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteReservation(@PathVariable("id") Long reservationId) {
        businness.deleteReservation(reservationId);
    }

    //Saber cuántas reservas se han hecho en un intervalo de tiempo
    @GetMapping("/report-dates/{dateOne}/{dateTwo}")
    public List<Reservation> getReservationsReportDates(@PathVariable("dateOne") String dateOne,@PathVariable("dateTwo") String dateTwo){
        return businness.getReservationPeriod(dateOne,dateTwo);
    }

    //Conteo de Reservas completadas vs canceladas: reporte de reservas con la cantidad de completas vs la cantidad de reservas canceladas
    @GetMapping("/report-status")
    public StatusAmount getReservationsStatusReport(){
        return businness.getReservationsByStatusReport();
    }

    //Top mejores clientes:Saber los que más han rentado.
    @GetMapping("/report-clients")
    public List<CountClient> getReservationsReportClient(){
        return businness.getTopClients();
    }
}

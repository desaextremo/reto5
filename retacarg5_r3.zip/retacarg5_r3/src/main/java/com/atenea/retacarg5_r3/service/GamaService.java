package com.atenea.retacarg5_r3.service;

import com.atenea.retacarg5_r3.entity.Gama;
import com.atenea.retacarg5_r3.repository.GamaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Service
public class GamaService {
    @Autowired
    private GamaRepository repository;

    //listar Gamas
    public List<Gama> getGamas(){
        return repository.findAll();
    }

    //Lista una gama a partir de su id
    public Optional<Gama> getGama(Long idValue){
        return repository.findById(idValue);
    }

    //Registrar Gama
    public Gama addGama(Gama gama){
        return repository.save(gama);
    }

    //Actualizar una Gama
    public Gama saveGama(Gama objeto){
        if (objeto.getIdGama()!= null){
            Optional<Gama> optional = repository.findById(objeto.getIdGama());

            if(optional.isPresent()){
                Gama gamaDb = optional.get();

                if (!objeto.getName().equals("")) gamaDb.setName(objeto.getName());
                if (!objeto.getDescription().equals("")) gamaDb.setDescription(objeto.getDescription());

                return repository.save(gamaDb);
            }
        }
        return objeto;
    }

    //borrar una Gama
    public void deleteGama(Long idGama){
        repository.deleteById(idGama);
    }
}

package com.atenea.retacarg5_r3.pojo;

import com.atenea.retacarg5_r3.entity.Car;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Builder
public class CountCar {
    private Long total;
    private Car car;
}

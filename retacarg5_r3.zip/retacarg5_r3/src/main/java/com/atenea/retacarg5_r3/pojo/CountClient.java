package com.atenea.retacarg5_r3.pojo;

import com.atenea.retacarg5_r3.entity.Client;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Builder
public class CountClient {
    private Long total;
    private Client client;
}

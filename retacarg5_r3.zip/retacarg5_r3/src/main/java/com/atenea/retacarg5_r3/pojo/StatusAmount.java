package com.atenea.retacarg5_r3.pojo;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Builder
public class StatusAmount {
    private int completed;
    private int cancelled;
}

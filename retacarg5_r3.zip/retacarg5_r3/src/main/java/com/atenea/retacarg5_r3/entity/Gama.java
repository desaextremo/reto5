package com.atenea.retacarg5_r3.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name="gamas")
public class Gama {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idGama;
    @Column(nullable = false,length = 45)
    private String name;
    @Column(nullable = false,length = 250)
    private String description;
    
    //Relacion con Carro
    @OneToMany(cascade = CascadeType.PERSIST,mappedBy = "gama")
    @JsonIgnoreProperties("gama")
    private List<Car> cars;
}
